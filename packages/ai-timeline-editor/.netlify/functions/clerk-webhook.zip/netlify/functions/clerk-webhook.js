var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var clerk_webhook_exports = {};
__export(clerk_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(clerk_webhook_exports);
var import_node_crypto = __toESM(require("node:crypto"), 1);
var import_supabase_js = require("@supabase/supabase-js");
const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SIGNING_SECRET;
const TOLERANCE_MS = 5 * 60 * 1e3;
function getHeader(headers, name) {
  if (!headers) return void 0;
  const key = Object.keys(headers).find((k) => k.toLowerCase() === name.toLowerCase());
  return key ? headers[key] : void 0;
}
function verifySvix(body, headers) {
  if (!WEBHOOK_SECRET) {
    console.error("[clerk-webhook] CLERK_WEBHOOK_SIGNING_SECRET is not set");
    return false;
  }
  const id = getHeader(headers, "svix-id") || getHeader(headers, "webhook-id");
  const timestamp = getHeader(headers, "svix-timestamp") || getHeader(headers, "webhook-timestamp");
  const signatures = getHeader(headers, "svix-signature") || getHeader(headers, "webhook-signature");
  if (!id || !timestamp || !signatures) {
    console.error("[clerk-webhook] Missing Svix headers");
    return false;
  }
  const ts = Number(timestamp) * 1e3;
  if (Number.isNaN(ts) || Math.abs(Date.now() - ts) > TOLERANCE_MS) {
    console.error("[clerk-webhook] Timestamp outside tolerance");
    return false;
  }
  const key = Buffer.from(WEBHOOK_SECRET.replace(/^whsec_/, ""), "base64");
  const signedContent = `${id}.${timestamp}.${body}`;
  const expected = import_node_crypto.default.createHmac("sha256", key).update(signedContent).digest("hex");
  const provided = signatures.split(",").map((s) => s.trim().replace(/^v1,/, ""));
  const valid = provided.some((sig) => {
    if (sig.length !== expected.length) return false;
    return import_node_crypto.default.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  });
  if (!valid) console.error("[clerk-webhook] Signature mismatch");
  return valid;
}
async function syncUser(eventType, data) {
  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    console.log("[clerk-webhook] Supabase not configured \u2014 skipping DB sync");
    return;
  }
  const supabase = (0, import_supabase_js.createClient)(url, serviceKey);
  const clerkId = data.id;
  if (eventType === "user.deleted") {
    const { error: error2 } = await supabase.from("users").delete().eq("clerk_id", clerkId);
    if (error2) console.error("[clerk-webhook] delete failed:", error2.message);
    return;
  }
  const primaryEmail = data.email_addresses?.find(
    (e) => e.id === data.primary_email_address_id
  )?.email_address;
  const name = [data.first_name, data.last_name].filter(Boolean).join(" ") || data.username || null;
  const { error } = await supabase.from("users").upsert(
    {
      clerk_id: clerkId,
      email: primaryEmail ?? null,
      name,
      image_url: data.image_url ?? null,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    },
    { onConflict: "clerk_id" }
  );
  if (error) console.error("[clerk-webhook] upsert failed:", error.message);
}
const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const body = typeof event.body === "string" ? event.body : event.body?.toString?.() ?? "";
  if (!verifySvix(body, event.headers)) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid signature" }) };
  }
  let payload;
  try {
    payload = JSON.parse(body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  try {
    await syncUser(payload.type, payload.data || {});
  } catch (err) {
    console.error("[clerk-webhook] sync error:", err.message);
  }
  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
